<html> 
    <head>
       <link rel="stylesheet" href="new home.css" >
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>      
 <body>
<img src="logo.PNG" height="100px" width="100px">
<h2><i>WELCOME TO UNIVERSITY OF RWANDA HUYE CAMPUS</i></h2>
<div class="log">
<div class="dropdown ">
    <button class="button button1"> LOGIN</button><br><br>
    <div class="dropdown-content">
        <a href="user.php">user</a>
        <a href="adimin.php">admin</a>
    </div>  
</div>
</div>
<div class="upp">
    <ul>
        <li><a href="#home">Home</a></li>
        <li  style="float:right"><a href="u.r registration sinup.php">u.r registration</a></li>
        <li  style="float:right"><a href="contact.html">contact us</a></li>
        <li  style="float:right"><a href="about .html">About us </a></li>
       
      </ul>
    </div>
<img src="h.PNG" width="100%" height="60%">
<footer>
    <p><i>follow us non </i></p>
<p>
    <a href="https://www.facebook.com/UniversityofRwanda/" class="fa fa-facebook"></a>
    <a href="https://twitter.com/Uni_Rwanda" class="fa fa-twitter"></a>
    <a href="https://www.youtube.com/channel/UCFu23eC8FXDiV3_ZiSAixyw" class="fa fa-youtube"></a>
    
    <a href="https://www.instagram.com/UniversityofRwanda/" class="fa fa-instagram"></a>    

</p>
<h3 style=" position: absolute;bottom: 1%;right:4%;">copyright 2021 at University of Rwanda  huye campus</h3>
</footer>

 </body>   


































</html>