<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="dashboard.css">
<body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:50%">
  <div class="w3-container w3-dark-grey">
    <h4>DASH BORD</h4>
  </div>

  <img src="logo.PNG" alt="Snow" style="width:10%">
  <a href="#" class="w3-bar-item w3-button w3-red">Home</a>
  <a href="#" class="w3-bar-item w3-button">MY PROFILE <span class="w3-tag w3-red w3-right w3-margin-right"></span></a>
  <a href="hosteldetails.php" class="w3-bar-item w3-button">HOSTEL DETAILS</a>
  <a href="roomdetails.php" class="w3-bar-item w3-button">ROOM DETAILS</a>
  
  <a href="#" class="w3-bar-item w3-button">MESSAGES</a>
  <a href="hostdispay.php" class="w3-bar-item w3-button">APLICANTS</a>
  <a href="displayacces.php" class="w3-bar-item w3-button">ACCESS LOGIN</a>

 

</div>

<div style="margin-left:50%">

<div class="w3-container">
<h2>admin</h2>
<p><img src="dash.png"></p>
</div>

</div>
      
</body>
</html>
